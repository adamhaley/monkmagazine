# Languages

## Generating POT

The generated POT template file is not included in this repository. It gets generated when building the project:

```
npm run build:client
```

After the build completes, you'll find a `woocommerce-payments.pot` strings file in this directory. 
